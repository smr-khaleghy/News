module.exports = {
    sources: [
        { value: '', label: '-- ALL --' },
        { value: 'na', label: 'News Api' },
        { value: 'gd', label: 'Guardian' },
        { value: 'nt', label: 'New york Times' }
    ]
}