module.exports = {
    guardianApiKey: "463e557c-72aa-4aef-aa23-81aff3f49b5c",
    newApisApiKey: "a1056583e07142e38e9a9a5ac207ef39",
    nyTimesApiKey: "swIKXiL46Z31dI8U95vJmH5JbSZQUe4q",
}